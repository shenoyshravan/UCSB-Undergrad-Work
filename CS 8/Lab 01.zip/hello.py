# Shravan Shenoy, for CMPSC 8, Spring 2019
print ('Hello, World!')
